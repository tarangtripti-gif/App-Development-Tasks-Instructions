# CodeAlpha Android App Development Internship Tasks

This repository contains the solutions for three Android app development tasks assigned as part of the CodeAlpha Internship program. Each task is implemented as a separate Android project.

## Table of Contents
1. [Task 1: Flashcard Quiz App](#task-1-flashcard-quiz-app)
2. [Task 2: Random Quote Generator](#task-2-random-quote-generator)
3. [Task 3: Fitness Tracker App](#task-3-fitness-tracker-app)
4. [Setup and Installation](#setup-and-installation)
5. [Uploading to GitHub](#uploading-to-github)

## Task 1: Flashcard Quiz App

### Description
This application allows users to create, manage, and review flashcards for studying. Users can navigate through flashcards, reveal answers, and add, edit, or delete flashcards.

### Features
- **Create Flashcards**: Add new flashcards with a question and an answer.
- **View Flashcards**: Navigate through existing flashcards using "Next" and "Previous" buttons.
- **Show Answer**: Reveal the answer to the current flashcard.
- **Edit Flashcards**: Modify the question and answer of an existing flashcard.
- **Delete Flashcards**: Remove unwanted flashcards.
- **Simple UI**: Clean and intuitive user interface for ease of use.

### Files
- `app/src/main/java/com/codealpha/flashcardapp/MainActivity.java`: Main activity for handling UI and logic.
- `app/src/main/java/com/codealpha/flashcardapp/Flashcard.java`: Data model for a flashcard.
- `app/src/main/res/layout/activity_main.xml`: Layout for the main screen.
- `app/src/main/res/layout/dialog_flashcard.xml`: Layout for the add/edit flashcard dialog.

## Task 2: Random Quote Generator

### Description
This app displays random inspirational quotes. Users can click a button to generate a new quote, which includes both the quote text and its author.

### Features
- **Random Quote Display**: Shows a new random quote each time the app is opened or a button is clicked.
- **Author Attribution**: Clearly displays the author of each quote.
- **Minimalist UI**: Simple and clean user interface for a better user experience.

### Files
- `app/src/main/java/com/codealpha/quotegenerator/MainActivity.java`: Main activity for generating and displaying quotes.
- `app/src/main/res/layout/activity_main.xml`: Layout for the main screen.

## Task 3: Fitness Tracker App

### Description
This application allows users to log various fitness activities and view a summary of their progress. It tracks activity type, steps, and calories burned.

### Features
- **Log Activities**: Add new fitness activities including type, steps, and calories burned.
- **Activity Summary**: Displays a dashboard with total activities logged, total steps, and total calories burned.
- **Simple UI**: Clean and user-friendly interface.

### Files
- `app/src/main/java/com/codealpha/fitnesstracker/MainActivity.java`: Main activity for logging activities and displaying the summary.
- `app/src/main/java/com/codealpha/fitnesstracker/FitnessActivity.java`: Data model for a fitness activity.
- `app/src/main/res/layout/activity_main.xml`: Layout for the main dashboard screen.
- `app/src/main/res/layout/dialog_log_activity.xml`: Layout for the log activity dialog.

## Setup and Installation

To run these projects, you will need Android Studio installed on your machine.

1.  **Clone the repository** (or download the zip and extract):
    ```bash
    git clone <repository_url>
    ```
2.  **Open in Android Studio**:
    -   Launch Android Studio.
    -   Select `File > Open` and navigate to the `CodeAlpha_Tasks` directory.
    -   Select one of the task folders (e.g., `Task1_FlashcardApp`) and click `Open`.
3.  **Sync Gradle**: Android Studio will automatically sync Gradle. If not, click `File > Sync Project with Gradle Files`.
4.  **Run on Emulator/Device**:
    -   Select an emulator or connect an Android device.
    -   Click the `Run` button (green triangle icon) in the toolbar.

## Uploading to GitHub

1.  **Initialize a Git repository** in the `CodeAlpha_Tasks` directory:
    ```bash
    cd CodeAlpha_Tasks
    git init
    ```
2.  **Add all files** to the staging area:
    ```bash
    git add .
    ```
3.  **Commit the changes**:
    ```bash
    git commit -m "Initial commit for CodeAlpha Android Internship Tasks"
    ```
4.  **Create a new repository on GitHub** (e.g., `CodeAlpha_Android_Tasks`). Do NOT initialize it with a README, .gitignore, or license.
5.  **Link your local repository to the remote GitHub repository**:
    ```bash
    git remote add origin https://github.com/YOUR_USERNAME/CodeAlpha_Android_Tasks.git
    ```
    (Replace `YOUR_USERNAME` and `CodeAlpha_Android_Tasks.git` with your actual GitHub username and repository name.)
6.  **Push your local commits to GitHub**:
    ```bash
    git push -u origin master
    ```
    (If your default branch is `main`, use `git push -u origin main` instead.)

---
**Author**: Manus AI
**Date**: June 30, 2026
